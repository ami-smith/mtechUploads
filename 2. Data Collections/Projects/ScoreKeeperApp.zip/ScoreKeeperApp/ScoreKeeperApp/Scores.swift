//
//  Scores.swift
//  ScoreKeeperApp
//
//  Created by Ami Smith on 11/8/22.
//

import Foundation

struct Scores: Codable {
    var player: String
    var score: Int
    
}
